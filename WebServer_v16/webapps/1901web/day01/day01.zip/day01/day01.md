
# 代理模式

在不改变软件原有功能情况下，为软件扩展功能。

经典面试题目： 

	如何在不使用API的情况下，使ArrayList变成线程安全的集合。

	答案：1 使用代理模式为ArrayList扩展线程同步功能。
	2 或者使用 Java的动态代理 为ArrayList扩展线程同步功能。

# 动态代理

Java 提供的API，用于简化代理模式的实现。

# AOP 面向切面儿编程

在不改变软件原有功能情况下，为软件扩展功能。

AOP 的底层就是利用动态代理实现的，可以将AOP理解为动态代理的进一步封装。

使用Spring AOP步骤：

1. 导入Spring包 
2. 导入AspectJ包
	- Spring AOP 功能是利用 AspectJ API 实现的。
3. 在Spring配置文件中开启 AOP
4. 编写 切面处理组件
	- 其作用类似于 InvocationHandler 
5. 获取Spring 容器中的对象，对象会被自动代理。

## 通知

指 AOP 方法的执行时机：

- @Around 环绕，在目标方法前后执行
- @Before 之前，在目标方法之前执行
- @After 之后，在目标方法之后执行，无论是否有异常都执行
- @AfterReturning 返回之后，在目标方法正常执行执行之后，没有异常时候执行。
- @AfterThrowing 抛出之后，在目标方法正常执行执行之后，有异常情况下执行

## 切入点表达式

设定 AOP 方法的具体切入位置： 哪些对象，哪些类，哪些方法

1. Bean 切入点表达，将AOP切入到bean组件的全部方法，如果处理多个组件可以使用通配符，或者 || 连接
	- bean(userService)
	- bean(userService) || bean(addressService)
	- bean(*Service)
2. execution 执行，执行方法级别的切入
	- execution(返回值 包名.类名.方法名(参数))
	- `execution(* cn.tedu.store.service.IUserService.login(..))`
	- `execution(* cn.tedu.store.service.*Service.get*(..))`
	- `execution(* cn.tedu.store.service.*Service.*(..))`
	- `execution(* cn.tedu.store.**.*Service.*(..))`
3. within 类级别的切入
	- within(包名.类名)
	- within(cn.tedu.store.service.impl.UserServiceImpl)
	- within(cn.tedu.store.service.impl.*ServiceImpl)
	
## AOP 的经典用途

1. 声明式事务处理 @Transactional 的底层就是AOP
2. 日志
3. 性能测试
4. 功能审计 或 埋点跟踪

等

# Java 基础

字符是一个数字

经典面试题目： 统计一个英文大写字符串中每个字符出现的个数。

	“AABCDEIIDDJAJAUUEHHOOJMCJ”

分析：

	统计结果：26个	 用数组存储统计结果
	int[] counter = new int[26];
	[0] 统计 'A'
	[1] 统计 'B'
	[2] 统计 'C'
	[3] 统计 'D'
	...
	[25] 统计 'Z'

	String str = "AABCDEIIDDJAJAUUEHHOOJMCJ";
	int[] counter = new int[26];
	for(int i=0; i<str.length(); i++){
		char c = str.charAt(i);
		// c='A' 65-65 = 0-> counter[0]++
		// c='B' 66-65 = 1-> counter[1]++
		// c='C' 67-65 = 2-> counter[2]++
		counter[c-'A']++;
	}
	
面试题目： 统计一个数字组成的字符串中每个数字的个数。





# 经典数据结构 

双向循环链表 二叉树 散列表

