
public class SampleTestCase {
	
	public static void main(String[] args) {
		Integer d = (int) Math.ceil(1.0 * 10 / 3);
		System.out.println(d);
		
		System.out.println(1.);
		System.out.println(.0);
	}

}
