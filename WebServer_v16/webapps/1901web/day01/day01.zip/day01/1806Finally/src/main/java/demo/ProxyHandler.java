package demo;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class ProxyHandler<E> implements InvocationHandler {

	private List<E> target;
	
	public ProxyHandler() {
		this(new ArrayList<E>());
	}
	
	public ProxyHandler(List<E> list) {
		this.target = list;
	}
	
	public Object invoke(Object proxy, 
			Method method, Object[] args) 
			throws Throwable {
		System.out.println("Call:"+method); 
		synchronized (target) {
			//��Ŀ�������ִ�ж�Ӧ�Ľӿڷ���
			return method.invoke(target, args);
		}
	}
}








