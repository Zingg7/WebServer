package demo;

import java.lang.reflect.Proxy;
import java.util.List;

public class ProxyDemo {

	public static void main(String[] args) {
		
		/*
		 * ʹ�ö�̬������ΪArrayList����ͬ�����ܣ������
		 * �̰߳�ȫ���⡣
		 */
		
		List<String> list = 
				(List<String>)Proxy.newProxyInstance(
				List.class.getClassLoader(), 
				new Class[]{List.class}, 
				new ProxyHandler<String>());
		System.out.println(list.getClass()); 
		list.add("Tom");
		list.add("Jerry");
		list.add("Andy");
		System.out.println(list.size());
		System.out.println(list);
	}

}




