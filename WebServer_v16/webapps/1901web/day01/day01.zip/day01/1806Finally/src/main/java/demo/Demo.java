package demo;

import java.util.List;

public class Demo {

	public static void main(String[] args) {
		/**
		 * ���Դ���ģʽ
		 */
		List<String> list=new ProxyList<String>();
		list.add("Tom");
		list.add("Jerry");
		System.out.println(list); 
 	}

}
