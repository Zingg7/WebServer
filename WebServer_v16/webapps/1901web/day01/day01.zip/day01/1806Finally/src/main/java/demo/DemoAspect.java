package demo;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect  //Aspect ����� ���
public class DemoAspect {
	
	@Around("bean(userService)")
	public Object test(ProceedingJoinPoint jp)
		throws Throwable {
		System.out.println("Call:"+jp.getSignature());
		synchronized (this) {
			return jp.proceed(); //method.invoke()
		}
	}
}


