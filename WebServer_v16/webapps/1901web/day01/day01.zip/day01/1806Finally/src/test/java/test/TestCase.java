package test;

 

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCase {
	
	ClassPathXmlApplicationContext ctx;
	@Before
	public void init(){
		ctx = new ClassPathXmlApplicationContext(
				"spring-aop.xml");
	}
	@Test
	public void testList(){
		List<String> list = ctx.getBean("listBean",
				List.class);
		System.out.println(list.getClass());
		list.add("Tom");
		list.add("Jerry");
		list.add("Andy");
		System.out.println(list);
	}
	
}




